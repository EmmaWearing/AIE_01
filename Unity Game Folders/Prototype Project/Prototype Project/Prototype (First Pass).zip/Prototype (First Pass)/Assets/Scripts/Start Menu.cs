﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartMenu : MonoBehaviour {


//A Bool to determine if the Start button is pressed
//	bool startButton;
//A Bool to determine if the Quit Button is pressed
//	bool quitButton;
//
//----------------------------------------------------------------------------------------------
//			 Update()
//Runs every frame
//
//Param
//			None
//Return
//			Void
//----------------------------------------------------------------------------------------------
//	void Update () {
//
//		if (startButton == true) {
//			SceneManager.LoadScene("Main", LoadSceneMode.Additive);
//		}
//
//		if (quitButton == true) {
//			Application.Quit ();
//		}
//
//
//	}
}

