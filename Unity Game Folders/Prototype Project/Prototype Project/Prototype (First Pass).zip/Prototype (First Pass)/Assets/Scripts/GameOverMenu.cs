﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOverMenu : MonoBehaviour {

	//A Bool to indicate if the Play Again Button is pressed
	//	bool playAgainButton;
	//A Bool to indicate if the Quit Button is pressed
	//	bool quitButton;

	//----------------------------------------------------------------------------------------------
	//			 Start()
	//Runs during initialisation
	//
	//Param
	//			None
	//Return
	//			Void
	//----------------------------------------------------------------------------------------------
	//	// Use this for initialization
	//	void Start () {
	//		
	//	}
	//----------------------------------------------------------------------------------------------
	//			Update()
	//Runs every frame
	//
	//Param
	//			None
	//Return
	//			Void
	//----------------------------------------------------------------------------------------------	
	//	void Update () {
	//		if (playAgainButton == true) {
	//			SceneManager.LoadScene ("Main", LoadSceneMode.Additive);
	//		}
	//		if (quitButton == true) {
	//			Application.Quit ();
	//		}
	//	}
}
