﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillZone : MonoBehaviour {

	public GameObject player1;
	public GameObject player2;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter (Collider other){
		if (other.tag == "Player") {
			player1.GetComponent<Player> ().Respawn ();
		}
		if (other.tag == "Player2") {
			player2.GetComponent<Player> ().Respawn ();
		}
	}
}
