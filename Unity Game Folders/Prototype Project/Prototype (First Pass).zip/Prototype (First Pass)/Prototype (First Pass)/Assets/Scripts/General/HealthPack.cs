﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthPack : MonoBehaviour {

	public GameObject healthPack;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}


	void OnTriggerEnter (Collider other){
		if (other.tag == "Player") {
			other.GetComponent<Player> ().HealthPack();
			Destroy (this.gameObject);
		}
		if (other.tag == "Player2") {
			other.GetComponent<Player> ().HealthPack ();
			Destroy (this.gameObject);
		}
	}
}
