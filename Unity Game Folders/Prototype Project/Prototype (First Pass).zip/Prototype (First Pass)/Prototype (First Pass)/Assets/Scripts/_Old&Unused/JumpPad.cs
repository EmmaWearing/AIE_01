﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpPad : MonoBehaviour {

	public GameObject player;
	public GameObject player2;

	public float jumpForce;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter(Collider other){
		if ((other.tag == "Player") && XboxCtrlrInput.XCI.GetButton(XboxCtrlrInput.XboxButton.A)) {
			Debug.Log("jumpy jumpy jumpy");
			player.transform.Translate (Vector3.up * jumpForce);
		}
		if ((other.tag == "Player2") && XboxCtrlrInput.XCI.GetButton(XboxCtrlrInput.XboxButton.A)) {
			player2.transform.Translate (Vector3.up * jumpForce);
		}
	}
}
